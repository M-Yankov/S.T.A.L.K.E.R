﻿namespace Santase.AI.StalkerPlayer.Common.Constants
{
    public class CardChooserConstants
    {
        public const int ClosedGamePriority = -1;

        public const int OpenGamePriority = 5;
    }
}