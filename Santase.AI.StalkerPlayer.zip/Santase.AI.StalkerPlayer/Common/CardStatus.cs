﻿namespace Santase.AI.StalkerPlayer.Common
{
    public enum CardStatus
    {
        InDeckOrEnemy = 0,
        Passed = 1,
        InStalker = 2,
        InEnemy = 3
    }
}
